The app contains social functions, like chats, with the objective users can share information.

· Consequently, the app can ask the user to enter personal data such as pictures or birthday.

· These personal data are displayed to other users of the app. These data aren't shared with any other entity or third organizations.
· Users can delete their personal data using the link for that purpose that exists in the user profile options in the app.

· It's prohibited to publish content for adults only, like images with sexual content or images of extreme violence.
· We allow third-party companies to serve ads and collect certain anonymous information when you visit our app. These companies may use anonymous information such as your Google Advertising ID, your device type and version, browsing activity, location and other technical data relating to your device, in order to provide advertisements.
